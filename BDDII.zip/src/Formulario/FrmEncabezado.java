package Formulario;

import ConexionBD.Conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Aaron
 */
public class FrmEncabezado extends javax.swing.JFrame {

    static Connection cn;
    Conexion conection = new Conexion();
    static Statement s;
    static ResultSet rs;

    public FrmEncabezado() {
        initComponents();
        conectar();
        ArrayList<String> Provincias = new ArrayList<String>();
        Provincias = llenar_provincias();

        for (int i = 0; i < Provincias.size(); i++) {
            cmbprovincia.addItem(String.valueOf(Provincias.get(i)));
        }
        ArrayList<String> Cantones = new ArrayList<String>();
        Cantones = llenar_canton();
        for (int i = 0; i < Cantones.size(); i++) {
            cmbcanton.addItem(String.valueOf(Cantones.get(i)));
        }
        ArrayList<String> Parroquias = new ArrayList<String>();
        Parroquias = llenar_parroquia();
        for (int i = 0; i < Parroquias.size(); i++) {
            cmbparroquia.addItem(String.valueOf(Parroquias.get(i)));
        }

    }

    public void conectar() {
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:orcl";
            cn = DriverManager.getConnection(url, "Aaron", "12345");
            s = cn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error: " + e);
        }
    }

    public static ArrayList<String> llenar_provincias() {
        ArrayList<String> listaprovincias = new ArrayList<String>();
        String q = "SELECT * FROM PROVINCIAS";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaprovincias.add(rs.getString("PROVINCIA"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaprovincias;
    }

    public static ArrayList<String> llenar_canton() {
        ArrayList<String> listacantones = new ArrayList<String>();
        String q = "select * from provincias r, cantones u \n"
                + "where r.idprovincia = u.idprovinciafk and idprovincia = 17";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listacantones.add(rs.getString("CANTON"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listacantones;
    }

    public static ArrayList<String> llenar_parroquia() {
        ArrayList<String> listaparroquias = new ArrayList<String>();
        String q = "select * from cantones r, parroquias u \n"
                + "where r.idcanton = u.idcantonfk and idcanton = 43";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaparroquias.add(rs.getString("NOMPARROQUI"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaparroquias;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        spnhijos = new javax.swing.JSpinner();
        txtoficina = new javax.swing.JTextField();
        cmbprovincia = new javax.swing.JComboBox<>();
        cmbcanton = new javax.swing.JComboBox<>();
        cmbparroquia = new javax.swing.JComboBox<>();
        txtnacta = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        btnenviar = new javax.swing.JButton();
        fechaactual = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("REPÚBLICA DEL ECUADOR");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("FORMULARIO DE MATRIMONIO");

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/logo-inec-e1533649589950.png"))); // NOI18N

        jLabel3.setText("OFICINA DE REGISTRO CIVIL:");

        jLabel4.setText("PROVINCIA:");

        jLabel5.setText("CANTÓN:");

        jLabel6.setText("PARROQUIA:");

        jLabel7.setText("FECHA DE MATRIMONIO:");

        jLabel8.setText("ACTA DE INSCRIPCIÓN:");

        jLabel9.setText("NÚMERO DE HIJOS ");

        jLabel10.setText("RECONCIDOS POR EL");

        jLabel11.setText("PRESENTE MATRIMONIO:");

        jLabel12.setText("MATRIMONIO CON");

        jLabel13.setText("CAPITULACIÓN DE");

        jLabel14.setText("BIENES:");

        spnhijos.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SI", "NO" }));
        jComboBox1.setSelectedIndex(-1);

        btnenviar.setText("Enviar y Continuar");
        btnenviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnenviarActionPerformed(evt);
            }
        });

        fechaactual.setMaxSelectableDate(new java.util.Date(253370786511000L));
        fechaactual.setMinSelectableDate(new java.util.Date(-62135747889000L));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jLabel15)
                        .addGap(97, 97, 97)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel1))
                            .addComponent(jLabel2)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel3)
                        .addGap(4, 4, 4)
                        .addComponent(txtoficina, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(txtnacta, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addComponent(jLabel4))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jLabel5))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jLabel6))
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(4, 4, 4)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cmbprovincia, 0, 137, Short.MAX_VALUE)
                            .addComponent(cmbcanton, 0, 137, Short.MAX_VALUE)
                            .addComponent(cmbparroquia, 0, 137, Short.MAX_VALUE)
                            .addComponent(fechaactual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(63, 63, 63)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel9)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnenviar)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(spnhijos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel15))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtoficina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtnacta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel8))))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel4)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel5)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(spnhijos, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(jLabel10))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(20, 20, 20)
                                    .addComponent(jLabel11))
                                .addComponent(jLabel9)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel13))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel14))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cmbprovincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(cmbcanton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(cmbparroquia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(fechaactual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(btnenviar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnenviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnenviarActionPerformed

        String oficina = txtoficina.getText();
        int provincia = cmbprovincia.getSelectedIndex() + 1; //coge el nombre de la provicia 
        String acta = txtnacta.getText().toString();
        String hijos = spnhijos.getValue().toString();
        fechaactual.setDateFormatString("dd-MM-yyyy");
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String fecha = fechaactual.getDateFormatString();
        fecha = df.format(new Date());

        try {
            try {
                Class.forName("oracle.jdbc.OracleDriver");
            } catch (Exception e) {
                e.printStackTrace();
            }

            String BaseDeDatos = "jdbc:oracle:thin:@localhost:1521:orcl";
            Connection conexion = DriverManager.getConnection(BaseDeDatos, "Aaron", "12345");
            Statement s = conexion.createStatement();

            int executeUpdate = s.executeUpdate("INSERT INTO CAB_FORMULARIO VALUES (idcabecera.nextval,'" + oficina + "'," + provincia + "," + acta + "," + hijos + ",'" + fecha + "')");
            if (executeUpdate == 1) {
                ResultSet rs = s.executeQuery("SELECT * FROM CAB_FORMULARIO ORDER BY IDCABECERA ASC");
                javax.swing.JOptionPane.showMessageDialog(null, "Se ingreso el formulario en: " + oficina);
                FrmContrayente me = new FrmContrayente();
                me.setVisible(true);
                this.setVisible(false);
            } else if (executeUpdate == 0) {
                javax.swing.JOptionPane.showMessageDialog(null, "no se logro ingresar");
            }
            s.close();
            conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(FrmContrayente.class.getName()).log(Level.SEVERE, null, ex);

        }

    }//GEN-LAST:event_btnenviarActionPerformed

  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnenviar;
    private javax.swing.JComboBox<String> cmbcanton;
    private javax.swing.JComboBox<String> cmbparroquia;
    private javax.swing.JComboBox<String> cmbprovincia;
    private com.toedter.calendar.JDateChooser fechaactual;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSpinner spnhijos;
    private javax.swing.JTextField txtnacta;
    private javax.swing.JTextField txtoficina;
    // End of variables declaration//GEN-END:variables
}
