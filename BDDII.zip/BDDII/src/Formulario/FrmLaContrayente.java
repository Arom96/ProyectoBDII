/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Formulario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Aaron
 */
public class FrmLaContrayente extends javax.swing.JFrame {

    static Connection cn;
    static Statement s;
    static ResultSet rs;

    /**
     * Creates new form FrmLaContrayente
     */
    public FrmLaContrayente() {
        initComponents();
        conectar();
        ArrayList<String> Provincias = new ArrayList<String>();
        Provincias = llenar_provincias();
        for (int i = 0; i < Provincias.size(); i++) {
            cmbprovincia.addItem(String.valueOf(Provincias.get(i)));
        }
        ArrayList<String> Etnias = new ArrayList<String>();
        Etnias = llenar_etnia();
        for (int i = 0; i < Etnias.size(); i++) {
            cmbetnia.addItem(String.valueOf(Etnias.get(i)));
        }
        ArrayList<String> Nacionalidades = new ArrayList<String>();
        Nacionalidades = llenar_nacionalidad();
        for (int i = 0; i < Nacionalidades.size(); i++) {
            cmbnacionalidad.addItem(String.valueOf(Nacionalidades.get(i)));
        }
        ArrayList<String> Instruccion = new ArrayList<String>();
        Instruccion = llenar_instruccion();
        for (int i = 0; i < Instruccion.size(); i++) {
            cmbinstruccion.addItem(String.valueOf(Instruccion.get(i)));
        }
        ArrayList<String> EstadoCivil = new ArrayList<String>();
        EstadoCivil = llenar_estadocivil();
        for (int i = 0; i < EstadoCivil.size(); i++) {
            cmbestadocivil.addItem(String.valueOf(EstadoCivil.get(i)));
        }
        ArrayList<String> Cantones = new ArrayList<String>();
        Cantones = llenar_canton();
        for (int i = 0; i < Cantones.size(); i++) {
            cmbcanton.addItem(String.valueOf(Cantones.get(i)));
        }
        ArrayList<String> Parroquias = new ArrayList<String>();
        Parroquias = llenar_parroquia();
        for (int i = 0; i < Parroquias.size(); i++) {
            cmbparroquia.addItem(String.valueOf(Parroquias.get(i)));
        }
    }

    public void conectar() {
        try {
            String url = "jdbc:oracle:thin:@localhost:1521:orcl";
            cn = DriverManager.getConnection(url, "Aaron", "12345");
            s = cn.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error: " + e);
        }
    }

    public static ArrayList<String> llenar_provincias() {
        ArrayList<String> listaprovincias = new ArrayList<String>();
        String q = "SELECT * FROM PROVINCIAS";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaprovincias.add(rs.getString("PROVINCIA"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaprovincias;
    }

    public static ArrayList<String> llenar_canton() {
        ArrayList<String> listacantones = new ArrayList<String>();
        String q = "select * from provincias r, cantones u \n"
                + "where r.idprovincia = u.idprovinciafk and idprovincia = 17";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listacantones.add(rs.getString("CANTON"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listacantones;
    }

    public static ArrayList<String> llenar_parroquia() {
        ArrayList<String> listaparroquias = new ArrayList<String>();
        String q = "select * from cantones r, parroquias u \n"
                + "where r.idcanton = u.idcantonfk and idcanton = 43";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaparroquias.add(rs.getString("NOMPARROQUI"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaparroquias;
    }

    public static ArrayList<String> llenar_etnia() {
        ArrayList<String> listaetnia = new ArrayList<String>();
        String q = "SELECT * FROM ETNIA";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaetnia.add(rs.getString("TIPO"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaetnia;
    }

    public static ArrayList<String> llenar_nacionalidad() {
        ArrayList<String> listanacionalidad = new ArrayList<String>();
        String q = "SELECT * FROM NACIONALIDAD";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listanacionalidad.add(rs.getString("TIPONAC"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listanacionalidad;
    }

    public static ArrayList<String> llenar_instruccion() {
        ArrayList<String> listainstruccion = new ArrayList<String>();
        String q = "SELECT * FROM NIVELINSTRUCCION";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listainstruccion.add(rs.getString("DESCRIPCION"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listainstruccion;
    }

    public static ArrayList<String> llenar_estadocivil() {
        ArrayList<String> listaestadocivil = new ArrayList<String>();
        String q = "SELECT * FROM ESTADOCIVIL";
        try {
            rs = s.executeQuery(q);
            System.out.println("Correcto");
        } catch (Exception e) {
            System.out.println("error");
        }
        try {
            while (rs.next()) {
                listaestadocivil.add(rs.getString("DESCRIPCION"));
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        return listaestadocivil;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtnombres = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtapellidos = new javax.swing.JTextField();
        txtcedula = new javax.swing.JTextField();
        spedad = new javax.swing.JSpinner();
        spanteriores = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        cmbnacionalidad = new javax.swing.JComboBox<>();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cmbestadocivil = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        cmbetnia = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cmblsino = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        cmbinstruccion = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        btnterminar = new javax.swing.JButton();
        txtlocalidad = new javax.swing.JTextField();
        cmbprovincia = new javax.swing.JComboBox<>();
        cmbcanton = new javax.swing.JComboBox<>();
        cmbparroquia = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("(B) DATOS DE LA CONTRAYENTE");

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("NOMBRES:");

        jLabel3.setText("APELLIDOS:");

        spedad.setModel(new javax.swing.SpinnerNumberModel(0, 0, 65, 1));

        spanteriores.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        jLabel4.setText("NACIONALIDAD:");

        jLabel5.setText("No. CÉDULA");

        jLabel6.setText("O PASAPORTE:");

        jLabel7.setText("FECHA DE NACIMIENTO:");

        jLabel8.setText("EDAD:");

        jLabel20.setText("Años cumplidos a la fecha");

        jLabel21.setText("del matrimonio");

        jLabel22.setText("NÚMERO DE MATRIMONIOS");

        jLabel23.setText("ANTERIORES:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21)
                    .addComponent(jLabel23)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(57, 57, 57)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtnombres)
                            .addComponent(txtapellidos)
                            .addComponent(txtcedula, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbnacionalidad, 0, 164, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(spedad, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addGap(18, 18, 18)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spanteriores, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtnombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtapellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbnacionalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtcedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(spedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(spanteriores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setText("ESTADO CIVIL ANTERIOR:");

        jLabel10.setText("AUTOIDENTIFICACIÓN");

        jLabel11.setText("ÉTNICA DE LA");

        jLabel12.setText("CONTRAYENTE:");

        jLabel13.setText("¿SABE LEER Y ESCRIBIR?");

        cmblsino.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SI", "NO" }));
        cmblsino.setSelectedIndex(-1);

        jLabel14.setText("NIVEL DE INSTRUCCION ALCANZADO:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(cmbestadocivil, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbetnia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmblsino, 0, 250, Short.MAX_VALUE)
                    .addComponent(cmbinstruccion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbestadocivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbetnia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmblsino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbinstruccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel15.setText("RESIDENCIA HABITUAL DE LA CONTRAYENTE");

        jLabel16.setText("PROVINCIA:");

        jLabel17.setText("CANTON:");

        jLabel18.setText("PARROQUIA:");

        jLabel19.setText("LOCALIDAD:");

        btnterminar.setText("Enviar y Finalizar");
        btnterminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnterminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(0, 13, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbprovincia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmbcanton, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(btnterminar)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(cmbparroquia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtlocalidad))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(cmbprovincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(cmbcanton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(cmbparroquia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txtlocalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addComponent(btnterminar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(187, 187, 187)
                .addComponent(jLabel1))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnterminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnterminarActionPerformed
        String nombre = txtnombres.getText();
        String apellido = txtapellidos.getText();
        int nacionalidad = cmbnacionalidad.getSelectedIndex()+1;
        String cedula = txtcedula.getText();
        jDateChooser1.setDateFormatString("dd-MM-yyyy");
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String fecha = jDateChooser1.getDateFormatString();
        fecha = df.format(new Date());
        String edad = spedad.getValue().toString();
        String nmatrimonio = spanteriores.getValue().toString();
        int estado = cmbestadocivil.getSelectedIndex()+1;
        int etnia = cmbetnia.getSelectedIndex()+1;
        int instruccion = cmbinstruccion.getSelectedIndex()+1;
        int provincia = cmbprovincia.getSelectedIndex()+1;
        String localidad = txtlocalidad.getText();

        try {
            try {
                Class.forName("oracle.jdbc.OracleDriver");
            } catch (Exception e) {
                e.printStackTrace();
            }

            String BaseDeDatos = "jdbc:oracle:thin:@localhost:1521:orcl";
            Connection conexion = DriverManager.getConnection(BaseDeDatos, "Aaron", "12345");
            Statement s = conexion.createStatement();
            int executeUpdate = s.executeUpdate("INSERT INTO PERSONA VALUES (idpersona.nextval,'" + nombre + "', '" + apellido + "'," + nacionalidad + "," + cedula + ",'" + fecha + "'," + edad + "," + nmatrimonio + "," + estado + "," + etnia + "," + instruccion + "," + provincia + ",'" + localidad + "')");
            if (executeUpdate == 1) {
                ResultSet rs = s.executeQuery("SELECT * FROM PERSONA ORDER BY IDPERSONA ASC");
                javax.swing.JOptionPane.showMessageDialog(null, "Se ingreso el conyuge con CI: " + cedula);
                FrmLogin me = new FrmLogin();
                me.setVisible(true);
                this.setVisible(false);
            } else if (executeUpdate == 0) {
                javax.swing.JOptionPane.showMessageDialog(null, "no se logro ingresar");
            }
            s.close();
            conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(FrmEncabezado.class.getName()).log(Level.SEVERE, null, ex);

        }

    }//GEN-LAST:event_btnterminarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnterminar;
    private javax.swing.JComboBox<String> cmbcanton;
    private javax.swing.JComboBox<String> cmbestadocivil;
    private javax.swing.JComboBox<String> cmbetnia;
    private javax.swing.JComboBox<String> cmbinstruccion;
    private javax.swing.JComboBox<String> cmblsino;
    private javax.swing.JComboBox<String> cmbnacionalidad;
    private javax.swing.JComboBox<String> cmbparroquia;
    private javax.swing.JComboBox<String> cmbprovincia;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSpinner spanteriores;
    private javax.swing.JSpinner spedad;
    private javax.swing.JTextField txtapellidos;
    private javax.swing.JTextField txtcedula;
    private javax.swing.JTextField txtlocalidad;
    private javax.swing.JTextField txtnombres;
    // End of variables declaration//GEN-END:variables
}
